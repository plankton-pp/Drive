USE cactidb;
DROP TABLE IF EXISTS `ex_ip_overlapse_vrf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ex_ip_overlapse_vrf` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service` VARCHAR(128) COLLATE utf8mb4_general_ci,
  `vrf_name` VARCHAR(128) COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ex_ip_overlapse_vrf`
--

INSERT INTO `ex_ip_overlapse_vrf` (`service`, `vrf_name`)
VALUES('1001', 'sig'),
  ('1002', 'sig_voip'),
  ('1003', 'db_billing'),
  ('1004', 'media_ps'),
  ('1005', 'db'),
  ('1006', 'voip'),
  ('1010', 'iub'),
  ('1011', 'grx'),
  ('1012', 'ip_pbx'),
  ('1013', 's1'),
  ('1014', 'poi_testbed'),
  ('1019', 'ims'),
  ('1023', 'probe_dna'),
  ('1025', 'public_sig'),
  ('1026', 'ut_ims'),
  ('1027', 'twamp'),
  ('1028', 'grx_dtac'),
  ('1029', 'grx_awn'),
  ('1030', 'gi_twamp'),
  ('1031', 'two_G_db_billing'),
  ('1032', 'abis'),
  ('1033', 'poi_voip'),
  ('1035', 'share_awn_iub'),
  ('1036', 'mocn'),
  ('2000', 'service'),
  ('2002', 'service_da'),
  ('2005', 'share_awn_mub'),
  ('3001', 'partners'),
  ('3002', 'scada'),
  ('3003', 'user_lanoffice'),
  ('3004', 'user_net_mgt'),
  ('3005', 'internet'),
  ('4004', 'wifi_internet'),
  ('4005', 'wifi_access'),
  ('5000', 'db_ps'),
  ('5002', 'j1'),
  ('5003', 'sig_nep'),
  ('5004', 'infra_mgmt'),
  ('5005', 'db_udc'),
  ('5006', 'j3'),
  ('5010', 'nfv_underlay'),
  ('5011', 'user_lanoffice_DA'),
  ('5012', 'nep_db'),
  ('5013', 'nep_bss_vas'),
  ('5014', 'exp_sig'),
  ('5016', 'j3_sig'),
  ('5017', 'j3_bss_vas'),
  ('6001', 'b2b_aerothai'),
  ('7001', 'sig_testbed'),
  ('7004', 'media_ps_testbed'),
  ('7006', 'voip_testbed'),
  ('8001', 'border_lite'),
  ('8002', 'charging_lite'),
  ('8003', 'corporate_lite'),
  ('8004', 'dmz_lite'),
  ('8005', 'dtn_mgt_lite'),
  ('8006', 'eng_nms_lite'),
  ('8007', 'ipcc_ivr_lite'),
  ('8008', 'internal_server_lite'),
  ('8009', 'outsource_lite'),
  ('8010', 'partner_external_lite'),
  ('8011', 'partner_internal_lite'),
  ('8012', 'private_service_lite'),
  ('8013', 'public_service_lite'),
  ('8014', 'remote_lite'),
  ('8015', 'testbed_lite'),
  ('8016', 'user_lite'),
  ('8017', 'vas_lite'),
  ('9001', 'gi_corp_inet'),
  ('9002', 'gi_corp_inet_ll'),
  ('9005', 'gi_inet'),
  ('9017', 'rcs'),
  ('9018', 'gi_inet2');


-- /*!40000 ALTER TABLE `ex_ip_overlapse_vrf` ENABLE KEYS */;
-- UNLOCK TABLES `ex_ip_overlapse_vrf`;