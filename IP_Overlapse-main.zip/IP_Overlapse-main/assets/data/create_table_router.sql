USE cactidb;
DROP TABLE IF EXISTS `ex_ip_overlapse_router`;
/*!40101 SET @saved_cs_client     = @@character_set_client */
;
/*!50503 SET character_set_client = utf8mb4 */
;
CREATE TABLE `ex_ip_overlapse_router` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip` VARCHAR(20) COLLATE utf8mb4_general_ci,
  `router_name` VARCHAR(128) COLLATE utf8mb4_general_ci,
  `access_ip` VARCHAR(20) COLLATE utf8mb4_general_ci,
  `device_type` VARCHAR(30) COLLATE utf8mb4_general_ci,
  `access_status` VARCHAR(1) COLLATE utf8mb4_general_ci,
  `access_services` TEXT COLLATE utf8mb4_general_ci,
  `delay_time` VARCHAR(128) COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */
;
--
-- Dumping data for table `ex_ip_overlapse_router`
--

;
INSERT INTO `ex_ip_overlapse_router` (`ip`,`router_name`,`access_ip`,`device_type`,`access_status`,`access_services`,`delay_time`)
VALUES ('172.20.200.0', 'Network Address', '-', '-', '0','','0'),
  ('172.20.200.1','RST0001-CCR-01', '-', '-', '0','','0'),
  ('172.20.200.2', 'RST0001-CCR-02', '-', '-', '0','','0'),
  ('172.20.200.9', 'RST0001-CTR-01', '-', '-', '0','','0'),
  ('172.20.200.10', 'RST0001-CRR-01','10.13.0.4','nokia_sros','1','','30'),
  ('172.20.200.11','RST0001-CER-01','10.13.0.10','nokia_sros','1','71,73','5'),
  ('172.20.200.12','RST0001-CER-02','10.13.0.12','nokia_sros','1','71,73','5'),
  ('172.20.200.13','RST0001-CER-03','10.13.0.14','nokia_sros','1','71,73','5'),
  ('172.20.200.14','RST0001-CER-04','10.13.0.16','nokia_sros','1','71,73','5'),
  ('172.20.200.31', 'SNK0001-CCR-01', '-', '-', '0','', '0'),
  ('172.20.200.32', 'SNK0001-CCR-02', '-', '-', '0','', '0'),
  ('172.20.200.40','SNK0001-CRR-01','10.13.8.4','nokia_sros','1','','30'),
  ('172.20.200.41','SNK0001-CER-01','10.13.8.10','nokia_sros','1','71,73','5'),
  ('172.20.200.42','SNK0001-CER-02','10.13.8.12','nokia_sros','1','71,73','5'),
  ('172.20.200.43','SNK0001-CER-03','10.13.8.14','nokia_sros','1','71,73','5'),
  ('172.20.200.44','SNK0001-CER-04','10.13.8.16','nokia_sros','1','71,73','5'),
  ('172.20.200.69', 'PSI0001-CTR-01', '-', '-', '0','', '0'),
  ('172.20.200.71', 'PSI0001-CER-01', '-', '-', '0','', '0'),
  ('172.20.200.72', 'PSI0001-CER-02', '-', '-', '0','', '0'),
  ('172.20.200.101', 'PLK0002-CER-01', '-', '-', '0','', '0'),
  ('172.20.200.102', 'PLK0002-CER-02', '-', '-', '0','', '0'),
  ('172.20.200.131', 'KKN0001-CER-01', '-', '-', '0','', '0'),
  ('172.20.200.132', 'KKN0001-CER-02', '-', '-', '0','', '0'),
  ('172.20.200.161', 'SNI0002-CER-01', '-', '-', '0','', '0'),
  ('172.20.200.162', 'SNI0002-CER-02', '-', '-', '0','', '0');
-- /*!40000 ALTER TABLE `ex_ip_overlapse_router` ENABLE KEYS */
;