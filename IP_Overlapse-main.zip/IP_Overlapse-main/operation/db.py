from sqlalchemy import *
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.exc import InvalidRequestError

username = 'root'
password = 'dtac1800'
host = "localhost"
port_db = "3306"

engine = create_engine(
    f'mysql+mysqldb://{username}:{password}@{host}:{port_db}/cactidb')