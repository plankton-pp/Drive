from netmiko import ConnectHandler
import time
import multiprocessing as mp
import pandas as pd
import db
class Timer:
    def __init__(self):
        self.start_time = 0
        self.elapsed_time = 0
        self.paused = False
        self.pause_start_time = 0

    def start(self):
        if self.start_time != 0:
            raise RuntimeError("Timer already started.")
        self.start_time = time.time()
        self.pause_start_time = self.start_time
        
    def pause(self):
        if self.start_time == 0:
            raise RuntimeError("Timer not started.")
        if self.paused:
            raise RuntimeError("Timer already paused.")
        self.pause_start_time = time.time()
        self.paused = True
        
    def continue_(self):
        if self.start_time == 0:
            raise RuntimeError("Timer not started.")
        if not self.paused:
            raise RuntimeError("Timer not paused.")
        self.elapsed_time = self.elapsed_time + (time.time() - self.pause_start_time)
        self.paused = False

    def stop(self,message):
        if self.start_time == 0:
            raise RuntimeError("Timer not started.")
        self.elapsed_time = time.time() - self.start_time
        print(f"{message} usage: {round(self.elapsed_time,4)} sec(s)")


# Define the router credentials
username = "ipcorebackup"
password = "ipcore123Dtac@2023"
device_type = "nokia_sros"  # not support "nokia_7750_sr"


def shell_task(host_info):
    # Example usage:
        sub_job_timer = Timer()
        sub_job_timer.start()
        device = {
            "host": host_info['host_ip'],
            "username": username,
            "password": password,
            "device_type": device_type
        }
        
        
        # need ** for passing as kwargs parameter// shouldnot use (device) only
        ssh = ConnectHandler(**device)
        
        outputs = ""
        
        for command in host_info['command']:
            if ("envi" in command or "time" in command ):
                print(f"send 1st command: {command}")
                ssh.send_command(command)
                # print(f"ssh.send_command({command})")
            else:
                result = ssh.send_command_timing(command, int(host_info['delay_time'])) # 3 is 300,000 
                outputs = outputs + "\n" + result
                # print(f"ssh.send_command_timing({command}, {int(host_info['delay_time'])})")
        
        # Save the output to a file
        with open(f"../assets/shell_result/{host_info['host_name']}.txt", "w") as f:
            f.write(str(outputs))

        # Close the SSH connection
        sub_job_timer.stop(f"Done: {host_info['host_name']}")
        # print(" - -- - - - - - - - - - - - - - - - - - - - -- - ")
        ssh.disconnect()

if __name__ == "__main__":
    main_job_timer = Timer()
    main_job_timer.start()
    
    route_df = pd.read_sql('SELECT access_ip as host_ip, router_name as host_name,  access_services, delay_time FROM cactidb.ex_ip_overlapse_router WHERE access_status like "1";', db.engine)
    vrf_df = pd.read_sql('SELECT id, service, vrf_name FROM cactidb.ex_ip_overlapse_vrf;', db.engine)
    
    vrf_dict = {}
    for index, row in vrf_df.iterrows():
        vrf_dict[f"{row['id']}"] = row['vrf_name']
    
    host = []
    for index, row in route_df.iterrows():
        command_to_send = ["show time", "environment no more"]
        if("-CRR-" in row['host_name']):
            command_to_send.append("show router bgp routes vpn-ipv4")
        else:
            services = row['access_services'].split(",")
            for service in services:
                command_to_send.append(f"""show router service-name "{vrf_dict[service]}" route-table""")
            
        host.append({"host_name": row['host_name'], "host_ip": row['host_ip'],"delay_time": int(row['delay_time']), "command": command_to_send})
    # Create a pool of 4 processes.
    pool = mp.Pool(4)
    # Create a list of arguments for each task.

    # Submit the tasks to the pool.
    results = pool.map(shell_task, host)
    
    # Close the pool.
    pool.close()
    pool.join()
        
        
    main_job_timer.stop("Done all shelling route");
