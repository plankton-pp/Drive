import time

class Timer:
    def __init__(self):
        self.start_time = 0
        self.elapsed_time = 0
        self.paused = False
        self.pause_start_time = 0

    def start(self):
        if self.start_time != 0:
            raise RuntimeError("Timer already started.")
        self.start_time = time.time()
        self.pause_start_time = self.start_time
        
    def pause(self):
        if self.start_time == 0:
            raise RuntimeError("Timer not started.")
        if self.paused:
            raise RuntimeError("Timer already paused.")
        self.pause_start_time = time.time()
        self.paused = True
        
    def continue_(self):
        if self.start_time == 0:
            raise RuntimeError("Timer not started.")
        if not self.paused:
            raise RuntimeError("Timer not paused.")
        self.elapsed_time = self.elapsed_time + (time.time() - self.pause_start_time)
        self.paused = False

    def stop(self,message):
        if self.start_time == 0:
            raise RuntimeError("Timer not started.")
        self.elapsed_time = time.time() - self.start_time
        print(f"{message} usage: {round(self.elapsed_time,4)} sec(s)")


if __name__ == "__main__":
    # Example usage:
    timer = Timer()
    timer.start()

    # Code you want to measure the execution time of
    time.sleep(1)

    timer.pause()

    # Some other code

    timer.continue_()
    
    time.sleep(3)
    
    timer.pause()

    # More code

    timer.stop("test")
