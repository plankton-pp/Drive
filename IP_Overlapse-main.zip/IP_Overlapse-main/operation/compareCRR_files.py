import os
import re
import pandas as pd
import json
import time
import db
from cachetools import cached, TTLCache

# Create a cache with a maximum size of 100 and a time-to-live (TTL) of 60 seconds
cache = TTLCache(maxsize=100, ttl=10)
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)


class Router:
    def __init__(self, path_dir):
        self._path = path_dir
        self._file_name = ''
        self._df = pd.DataFrame()

    @property
    def get_path(self):
        return self._path

    def set_path(self, path):
        self._path = path

    def get_file_name(self):
        return self._file_name

    def set_file_name(self, file_name):
        self._file_name = file_name

    def get_file_path(self):
        return self._path+self._file_name

    def is_df_empty(self):
        return self._df.empty

    def init_df(self, df):
        self._df = df

    def append_df(self, df):
        self._df = pd.concat([self._df, df], ignore_index=True)

    def clean_df_row(self):
        # Drop rows where a condition is met
        self._df = self._df.drop(self._df[self._df['subnet'] == 0].index)
        self._df['id'] = range(1, len(self._df) + 1)

    def clean_df_dup(self):
        self._df = self._df.drop_duplicates()

    def extract_subnet(self, ip_address):
        patter_subnet = r"\/(\d+)$"
        subnet_match = re.search(patter_subnet, ip_address)
        if subnet_match:
            return subnet_match.group(1)
        else:
            return None

    def extract_ip_address(self, ip_with_subnet):
        ip_regex = r'^([\d.]+)'
        ip_match = re.match(ip_regex, ip_with_subnet)
        if ip_match:
            return ip_match.group(1)
        else:
            return None

    def create_subnet(self):
        self._df['full_ip'] = self._df['ip'].astype('string')
        self._df['ip'] = self._df['ip'].apply(self.extract_ip_address).astype('string')
        self._df['subnet'] = self._df['full_ip'].apply(self.extract_subnet).astype('int8')
        self._df['service'] = self._df['service'].astype('category')
        self._df['vpn_name'] = self._df['vpn_name'].astype('category')
        self._df['router_name'] = self._df['router_name'].astype('category')
        
    def get_vrf_name(self):
        vrf_df = pd.read_sql('SELECT service,vrf_name as vpn_name FROM cactidb.ex_ip_overlapse_vrf;', db.engine)
        vrf_df['service'] = vrf_df['service'].astype('string')
        vrf_df['vpn_name'] = vrf_df['vpn_name'].astype('string')
        # vrf_df = vrf_df.drop(columns=['id'])
        
        merged_df = self._df.merge(vrf_df, on='service', how='left')
        merged_df['vpn_name'].fillna(value="-", inplace=True)
        self._df = merged_df
        
    def get_route_name(self):
        route_df = pd.read_sql('SELECT ip as router_name, router FROM cactidb.ex_ip_overlapse_router;', db.engine)
        route_df['router_name'] = route_df['router_name'].astype('string')
        route_df['router'] = route_df['router'].astype('string')
        # vrf_df = vrf_df.drop(columns=['id'])
        
        merged_df = self._df.merge(route_df, on='router_name', how='left')
        merged_df['route'].fillna(value="-", inplace=True)
        merged_df['router_name'] = merged_df['route']
        merged_df = merged_df.drop(columns=['route'])
        self._df = merged_df

    # @cached(cache)
    def get_df(self):
        # start_time = time.time()
        # List all files in the directory
        files = os.listdir(self._path)

        # Iterate over the files and print the file names with their extensions
        for file in files:
            if os.path.isfile(os.path.join(self._path, file)):
                filename, extension = os.path.splitext(file)
                if (extension == ".txt"):
                    self.set_file_name(file)
                    file_group = self.get_reading_type()
                    [header, content] = [[], []]

                    if ("CER" in file_group):
                        [header, content] = self.get_cer()

                    # elif ("CRR" in file_group):
                    #     [header, content] = self.get_crr()

                    # keep_only = [header[0], header[-1]]
                    df = pd.DataFrame(content, columns=header)
                    # df = df[keep_only]
                    df = df.drop_duplicates()
                    if (self.is_df_empty()):
                        self.init_df(df)
                    else:
                        self.append_df(df)
                    self.clean_df_dup()

        # Create 'subnet' column using the 'ip' column and regex extraction
        self.get_vrf_name()
        self.get_route_name()
        self.create_subnet()
        self.clean_df_row()
        # end_time = time.time()
        # elapsed_time = end_time - start_time
        # print("usage: ", elapsed_time)
        return self._df

    def get_reading_type(self):
        # Define the regex pattern to extract the desired result
        pattern = r"\b([A-Z]{3})-\d{2}"
        result = re.search(pattern, self._file_name)
        if result:
            return result.group(1)
        else:
            return 'none'

    def match_ip(self, text):
        # Matches non-space characters followed by any character except space, square brackets, or newlines
        pattern = r"[^:]+$"
        matches = re.findall(pattern, text)
        # Remove leading/trailing spaces from each match
        return ''.join(matches)

    def match_service(self, text):
        # Matches non-space characters followed by any character except space, square brackets, or newlines
        pattern = r"(?<=:).*?(?=:)"
        matches = re.findall(pattern, text)
        # Remove leading/trailing spaces from each match
        return ''.join(matches)

    def match_router_crr(self, text):
        # Matches non-space characters followed by any character except space, square brackets, or newlines
        pattern = r"(?<=\b)\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?=:)"
        matches = re.findall(pattern, text)
        # Remove leading/trailing spaces from each match
        return ''.join(matches)

    def match_router_cer(self, file_name):
        pattern = r"[A-Za-z0-9]+.+(?=\()"
        matches = re.findall(pattern, file_name)
        # Remove leading/trailing spaces from each match
        return ''.join(matches)

    def get_cer(self):
        router_name = self.match_router_cer(self.get_file_name())
        with open(self.get_file_path(), 'r') as file:
            service = ''
            pattern_check = r'\d+d\d{2}h(?:\d{2}m)?'
            pattern_ip = r'\d{1,3}\.+.+\d{1,3}\/\d{1,2}?(?=\s{4}|$)'
            pattern_service = r'Service:\s(\d+)'
            table_content = []
            for line in file:
                if ('Service:' in line):
                    service_match = re.search(pattern_service, line)
                    if service_match:
                        # Print the matched result
                        service = service_match.group(1)[2:]

                else:
                    check_match = re.search(pattern_check, line)
                    if check_match:
                        match_ip = re.search(pattern_ip, line)
                        ip_addr = match_ip.group()
                        # Print the matched result
                        table_content.append(
                            [str(service), router_name, ip_addr])

        return [['service', 'router_name', 'ip'], table_content]

    # @cached(cache)
    def get_crr(self):
        with open(self.get_file_path(), 'r') as file:
            table_content = []
            for line in file:
                pattern = r'\d{1,3}\.+.+\:[0-9]+.+\/\d{1,2}'
                match = re.search(pattern, line)
                if match:
                    # Print the matched result
                    service = self.match_service(match.group())
                    router_name = self.match_router_crr(match.group())
                    # print(service)
                    ip_addr = self.match_ip(match.group())
                    table_content.append(
                        [str(service), router_name, ip_addr])
        return [['service', 'router_name', 'ip'], table_content]

# usage


if __name__ == "__main__":
    path = '../assets/data/'
    router = Router(path)
    ip_df = router.get_df()
    print(ip_df.head(10))
