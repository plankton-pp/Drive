class ipmanager:
    def ipv4_to_binary(self, ipv4_address):
        octets = ipv4_address.split('.')
        binary_octets = [format(int(octet), '08b') for octet in octets]
        binary_address = '.'.join(binary_octets)
        return binary_address

    def subnet_as_bit(self, decimal_bits):
        if decimal_bits < 0 or decimal_bits > 32:
            raise ValueError("Invalid decimal value for subnet bits")

        subnet_mask = 0xFFFFFFFF << (32 - decimal_bits) & 0xFFFFFFFF
        return ".".join(map(str, (subnet_mask >> 24, (subnet_mask >> 16) & 0xFF, (subnet_mask >> 8) & 0xFF, subnet_mask & 0xFF)))

    def apply_ipv4_to_binary(self, df, column_name, new_column_name):
        df[new_column_name] = df[column_name].apply(self.ipv4_to_binary).astype('string')
        return df
    
    def apply_sub_to_binary(self, df, column_name, new_column_name):
        df[new_column_name] = df[column_name].apply(lambda x: int(x)).apply(self.subnet_as_bit).apply(self.ipv4_to_binary).astype('string')
        return df

    def get_uniq_subnet(self, df, column_name):
        return df[column_name].unique()


if __name__ == "__main__":
    ipv4_address = '192.168.0.1'
    ip_ov = ipmanager()
    binary_address = ip_ov.ipv4_to_binary(ipv4_address)
    print(binary_address)

    # df['column_name'] = df['column_name'].apply(str.upper)
