from cachetools import cached, TTLCache
cache = TTLCache(maxsize=100, ttl=10)

from routing import Router
from iptools import ipmanager
from measure import Timer

import sys
import datetime
import multiprocessing as mp
import time
import pandas as pd
import numpy as np
from sqlalchemy import types, create_engine
from sqlalchemy.exc import InvalidRequestError
# Config DB communication
username = 'root'
password = 'dtac1800'
host = "localhost"
port_db = "3306"

# Disable the warning
pd.options.mode.chained_assignment = None

@cached(cache)
def get_df_to_db():
    sub_getdf_measure = Timer()
    sub_convert_binary = Timer()
    #------------------------------------------------------------------------------
    sub_getdf_measure.start()
    path = '../assets/shell_result/'
    router = Router(path)
    ip_ov = ipmanager()
    ip_df = router.get_df()
    sub_getdf_measure.stop("get df from routing file")
    #------------------------------------------------------------------------------
    sub_convert_binary.start()
    ip_df = ip_ov.apply_ipv4_to_binary(ip_df, 'ip', 'bi_ip')
    ip_df = ip_ov.apply_sub_to_binary(ip_df, 'subnet', 'bi_sub')
    sub_convert_binary.stop("convert to binary")

    return ip_df


def push_df_to_db(df):
    # Establish a connection to the database
    engine = create_engine(
        f'mysql+mysqldb://{username}:{password}@{host}:{port_db}/cactidb')

    try:
        with engine.connect() as con:
            con.execute('DROP TABLE IF EXISTS `ex_ip_overlapse`;')
            
        df.to_sql('ex_ip_overlapse', engine, if_exists='replace', index=False,
                  dtype={
                      'id': types.INT,
                      'service': types.INT,
                      'vpn_name': types.TEXT,
                      'router_name': types.TEXT,
                      'ip': types.VARCHAR(20),
                      'full_ip': types.VARCHAR(20),
                      'subnet': types.VARCHAR(3),
                      'bi_ip': types.VARCHAR(40),
                      'bi_sub': types.VARCHAR(40),
                      'parent_ip': types.TEXT,
                      'lastupdate': types.TIMESTAMP
                  })

        # Add foreign key constraints for the columns that reference other tables
        with engine.connect() as con:
            # ALTER TABLE sample_1 ADD CONSTRAINT fk_department_id FOREIGN KEY (id) REFERENCES departments(id) ON DELETE SET NULL
            # ALTER TABLE your_table ADD CONSTRAINT unique_column_name UNIQUE (column_name);

            con.execute(
                'ALTER TABLE ex_ip_overlapse ADD PRIMARY KEY (id), MODIFY COLUMN id INT NOT NULL AUTO_INCREMENT;')

        # Close the database connection
        engine.dispose()
        print(f"Wrote final input dataset to table '{'ex_ip_overlapse'}'.")
    except (ValueError, InvalidRequestError):
        print(f"Could not write to table '{'ex_ip_overlapse'}'.")

def replace_dot_sep(task_id,df,return_dict):
    df['bi_ip'] = df.apply(lambda row: row['bi_ip'][:row['subnet']], axis=1)
    return_dict[task_id] = df

def get_ip_groupby_subnet(df):
    task = 4
    manager = mp.Manager()
    return_dict = manager.dict()
    processes = []
    group = np.mod(df['id'], task)
    df_partitioned = [group_data.sort_values(by='subnet') for _, group_data in df.groupby(group)]
    
    for i, group_df in enumerate(df_partitioned):
        process = mp.Process(target=replace_dot_sep, args=(i,group_df,return_dict))
        process.start()
        processes.append(process)
        
    for proc in processes:
        proc.join()
        
    df_replaced = pd.DataFrame()
    for _ in return_dict.keys():
        df_replaced = pd.concat([df_replaced, return_dict[_]], ignore_index=True)
        
    uniq_subnet = df['subnet'].unique().tolist()
    subnet_dictionary = {}
    for subnet in uniq_subnet:
        subnet_dictionary[subnet] = df_replaced[df_replaced['subnet']<subnet]
        
    return subnet_dictionary

def find_parent(task,df,dict,return_dict):
    print(f"\nTask ({task}): {len(df)}")
    last_subnet = False
    start = time.perf_counter()
    uniq_subnet = []
    for index, parent_row in df.iterrows():
        if(last_subnet!=parent_row['subnet']):
            last_subnet = parent_row['subnet']
            df_filtered_subnet = dict[parent_row['subnet']]
            uniq_subnet = df_filtered_subnet['subnet'].unique().tolist()
            
        if(len(df_filtered_subnet)>0):
            df_shortcut = pd.DataFrame({
                'bi_ip': map(lambda position: parent_row['bi_ip'][:position], uniq_subnet),
            })
            df_intsec = df_filtered_subnet[df_filtered_subnet['bi_ip'].isin(df_shortcut['bi_ip'])]
            if(len(df_intsec)>0):
                df.loc[index,"parent_ip"] = ",".join(map(str, df_intsec['full_ip'].to_list()))
                # print(f"Task({task}): {parent_row['ip']} -> ",",".join(map(str, df_intsec['ip'].to_list())))
            else:
                df.loc[index,"parent_ip"] = "none"
                # print(f"Task({task}): {parent_row['ip']} -> None")
                
            del df_shortcut
            del df_intsec

        else:
            df.loc[index, 'parent_ip'] = "none"
    return_dict[task] = df
    finish = time.perf_counter()
    print(f"End Task({task}): usage {round(finish-start,6)} sec(s)\n")

class IPDataset:
    def __init__(self, df_full,df_partitioned,subnet_dictionary):
        self._df_full = df_full
        self._df_partitioned = df_partitioned
        self._subnet_dictionary = subnet_dictionary
        
    @property
    @cached(cache)
    def get_df_full(self):
        return self._df_full
    
    @cached(cache)
    def get_df_partitioned(self):
       return self._df_partitioned
   
    @cached(cache)
    def get_subnet_dictionary(self):
       return self._subnet_dictionary

if __name__ == "__main__":
    main_measure = Timer()
    sub_to_db_measure = Timer()
    main_measure.start()
    ip_ovl = get_df_to_db()
    ip_ovl['id'] = ip_ovl['id'].astype('uint32')
    
    #------------------------------------------------------------------------------
    # Making dictionary of subnet
    dictionary_m = Timer()
    dictionary_m.start()
    df_light_w = ip_ovl[['id','full_ip','subnet','bi_ip']].copy()
    df_light_w['bi_ip'] = df_light_w['bi_ip'].str.replace('.', '')
    df_light_w_drop = df_light_w.drop_duplicates(subset=['subnet', 'bi_ip']).sort_values(by='subnet')
    subnet_dictionary = get_ip_groupby_subnet(df_light_w_drop)
    dictionary_m.stop("making subnet dictionary")
    
    #------------------------------------------------------------------------------
    # Group the dataframe by the ID modulo 5 and iterate over the groups
    split_m = Timer()
    split_m.start()
    task = 4
    group = np.mod(df_light_w_drop['id'], task)
    df_partitioned = [group_data for _, group_data in df_light_w_drop.groupby(group)]
    dataset = IPDataset(df_light_w_drop,df_partitioned,subnet_dictionary)
    
    #------------------------------------------------------------------------------
    # Find Parent IP
    manager = mp.Manager()
    return_dict = manager.dict()
    processes = []
    dict = dataset.get_subnet_dictionary()
    start = time.perf_counter()
    
    for i, group_df in enumerate(df_partitioned):
        process = mp.Process(target= find_parent,args=[i,group_df,dict,return_dict])
        process.start()
        processes.append(process)
        
    for proc in processes:
        proc.join()
    
    finish = time.perf_counter()
    print(f"End Finding: usage {round(finish-start,6)} sec(s)\n")
    
    # Concatenate all DF in dictionary
    concat_m = Timer()
    concat_m.start()
    df_parent_found = pd.DataFrame()
    for _ in return_dict.keys():
        df_parent_found = pd.concat([df_parent_found, return_dict[_]], ignore_index=True)
    df_parent_found['parent_ip'] = df_parent_found['parent_ip'].astype('string')
    concat_m.stop("concat result")
    
    # Drop the column 'subnet','bi_ip','id'
    droping_m = Timer()
    droping_m.start()
    df_parent_found = df_parent_found.drop(columns=['subnet','bi_ip','id'])
    droping_m.stop("droping unnecessary column")
    
    
    # Merge the two DataFrames on 'ip'
    merging_m = Timer()
    merging_m.start()
    df_result = pd.merge(ip_ovl, df_parent_found, on='full_ip', how='left')
    df_result = df_result.drop_duplicates(subset="id")
    df_result['lastupdate'] = datetime.datetime.now()
    df_result['lastupdate'] = df_result['lastupdate'].dt.strftime('%Y-%m-%d %H:%M:%S')
    merging_m.stop("merging result")
    #------------------------------------------------------------------------------

    sub_to_db_measure.start()
    push_df_to_db(df_result)
    sub_to_db_measure.stop("push_df_to_db")

    print(
        f'The size of the integer variable is: {sys.getsizeof(ip_ovl)/(1024*1024)} MB.')
    main_measure.stop("__main__")