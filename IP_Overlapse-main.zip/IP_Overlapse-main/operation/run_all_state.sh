#create po and po invoice record
#mysql -uroot -pdtac1800 < ../assets/data/create_table_router.sql
#mysql -uroot -pdtac1800 < ../assets/data/create_table_vrf.sql
/usr/local/bin/python3 shell_router.py;
/usr/local/bin/python3 main.py;