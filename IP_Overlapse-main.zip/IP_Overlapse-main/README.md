# IP_Overlapse
Classify ip to cactidb before verify ip is overlapse by searching on TD-portal (provided by Python)
# IP Overlapse

IP Overlapse is a function for dealing with classifying IP and put to cactidb.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install pandas, numpy, multiprocessing, sqlalchemy.

```bash
pip install pandas
```

```bash
pip install numpy
```

```bash
pip install multiprocessing
```

```bash
pip install sqlalchemy
```

## Usage

make sure you have an user in cactiDB provided by K. Meta (Meta Polpasee)

```python
# Config DB communication
username = '** your cactiDB username**'
password = '** your cactiDB password **'
host = "** IP Address of cactiDB **"
port_db = "** Server's PORT **"
```

## Contributing

Pull requests are welcome. For major changes, please open an issue first
to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
DTAC TD-Transport

`Provided by Pacharapol Kaewkunlaya (Cutto)`